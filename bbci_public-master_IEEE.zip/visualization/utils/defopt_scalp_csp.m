function opt= defopt_scalp_csp(varargin)
%DEFOPT_SCALP_CSP - Properties for plot_scalp* functions, optimized for
%visualizing spatial filters or patterns, such as returned by CSP

props= {'Shading'               'interp'
        'Extrapolation'         0
        'Resolution'            101
        'LineProperties'        {'LineWidth',1}
%         'CLim'                  'sym'
        'CLim'                  [-0.2 0.2]
%         'Colormap'              cmap_greenwhi telila(31)
        'Colormap'              cmap_posneg(101)
        'Contour'               5
        'ContourPolicy'         'withinrange'
        'ContourLineprop'       {'LineWidth',0.3}
       };
    
opt= opt_proplistToStruct(varargin{:});
opt= opt_setDefaults(opt, props);
