
p = genpath(pwd);
addpath(p);

